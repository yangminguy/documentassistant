import React from 'react';
import { FileUploader } from './components/parser/FileUploader';

export function App() {
  return (
    <div className="p-8">
      <h1 className="text-2xl mb-4">SmartMailer</h1>
      <FileUploader />
    </div>
  );
}