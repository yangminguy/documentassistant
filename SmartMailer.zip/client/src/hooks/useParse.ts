import { useMutation } from 'react-query';

export function useParse() {
  return useMutation(async (file: File) => {
    const form = new FormData();
    form.append('file', file);
    const res = await fetch('/api/parse', { method: 'POST', body: form });
    if (!res.ok) throw new Error('Failed to parse file');
    return res.json();
  });
}