import React, { useState } from 'react';
import { useParse } from '../../hooks/useParse';
import { Button } from '../common/Button';

export function FileUploader() {
  const [file, setFile] = useState<File | null>(null);
  const mutation = useParse();

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (file) mutation.mutate(file);
  };

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <input
        type="file"
        accept=".xlsx,.xls,.csv"
        onChange={e => {
          const selected = e.target.files?.[0] || null;
          setFile(selected);
        }}
      />
      <Button type="submit" label="Parse" disabled={mutation.isLoading} />
      {mutation.data && <pre>{JSON.stringify(mutation.data.data, null, 2)}</pre>}
      {mutation.isError && <div>Error parsing file</div>}
    </form>
  );
}