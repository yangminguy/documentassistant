import { Router } from 'express';
import multer from 'multer';
import { ParseController } from '../controllers/parse.controller';

const upload = multer();
const router = Router();
router.post('/', upload.single('file'), ParseController.handle);
export { router as parseRouter };