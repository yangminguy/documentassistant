import 'reflect-metadata';
import { container } from 'tsyringe';
import { IParserService } from './services/parser/parser.interface';
import { ExcelParserService } from './services/parser/parser.service';
import { IEmailService } from './services/email/email.interface';
import { SendGridEmailService } from './services/email/email.service';
import { IAIService } from './services/ai/ai.interface';
import { OpenAIService } from './services/ai/ai.service';

container.registerSingleton<IParserService>('ParserService', ExcelParserService);
container.registerSingleton<IEmailService>('EmailService', SendGridEmailService);
container.registerSingleton<IAIService>('AIService', OpenAIService);