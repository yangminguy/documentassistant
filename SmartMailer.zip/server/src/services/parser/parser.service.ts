import { injectable } from 'tsyringe';
import { IParserService } from './parser.interface';
import XLSX from 'xlsx';

@injectable()
export class ExcelParserService implements IParserService {
  async parse(buffer: Buffer) {
    const workbook = XLSX.read(buffer, { type: 'buffer' });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    return XLSX.utils.sheet_to_json(sheet, { defval: null });
  }
}