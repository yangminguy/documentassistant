export interface IParserService {
  parse(buffer: Buffer): Promise<Record<string, unknown>[]>;
}