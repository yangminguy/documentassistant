import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import morgan from 'morgan';
import { json } from 'body-parser';
import { parseRouter } from './routes/parse.route';

export function createServer() {
  const app = express();
  app.use(morgan('combined'));
  app.use(cors({ origin: true }));
  app.use(json());
  app.use('/api/parse', parseRouter);
  app.use((err: any, req: Request, res: Response, next: NextFunction) => {
    const status = err.statusCode || 500;
    const message = err.message || 'Internal Server Error';
    res.status(status).json({ error: message });
  });
  return app;
}