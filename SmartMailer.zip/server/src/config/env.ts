import { z } from 'zod';

const envSchema = z.object({
  DATABASE_URL: z.string().url(),
  PORT: z.string().regex(/^\d+$/).transform(Number).default('3000'),
  OPENAI_API_KEY: z.string().min(1),
  SENDGRID_API_KEY: z.string().min(1),
  JWT_SECRET: z.string().min(32)
});

export const env = envSchema.parse(process.env);