import { Request, Response, NextFunction } from 'express';
import { container } from 'tsyringe';
import { IParserService } from '../services/parser/parser.interface';

export class ParseController {
  static async handle(req: Request, res: Response, next: NextFunction) {
    try {
      if (!req.file) throw { statusCode: 400, message: 'No file uploaded' };
      const parser = container.resolve<IParserService>('ParserService');
      const data = await parser.parse(req.file.buffer);
      res.json({ data });
    } catch (err) {
      next(err);
    }
  }
}